package ee.taltech.iti0202.coffee.exception;

public class NotEnoughResourceException extends RuntimeException {
    public NotEnoughResourceException(String resource, int asked, int have) {
        super("Not enough " + resource + ": was asked " + asked + ", but only have" + have);
    }
}

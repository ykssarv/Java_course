package ee.taltech.iti0202.coffee.exception;

public class NotEnoughWaterException extends RuntimeException {
    public NotEnoughWaterException(int asked, int have) {
        super("Was asked " + asked + " water, but container only has " + have);
    }
}

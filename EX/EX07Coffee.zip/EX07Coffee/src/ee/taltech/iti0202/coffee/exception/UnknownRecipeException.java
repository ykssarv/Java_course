package ee.taltech.iti0202.coffee.exception;

public class UnknownRecipeException extends RuntimeException {
    public UnknownRecipeException(String recipe) {
        super("Unknown recipe: " + recipe);
    }
}
